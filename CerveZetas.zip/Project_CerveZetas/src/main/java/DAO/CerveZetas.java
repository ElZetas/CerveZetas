/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.Direccion;
import DTO.TipoUsuario;
import DTO.Usuario;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ciclost
 */
public class CerveZetas {
    
    public static void main(String[] args) throws SQLException {
        MarcaDAO marca = new MarcaDAO();
        UsuarioDAO user = new UsuarioDAO();
        ProductoDAO pro = new  ProductoDAO();
        DireccionDAO dir = new DireccionDAO();
        PedidoDAO ped = new PedidoDAO();
        FacturaDAO fac = new FacturaDAO();
        
        System.out.println(fac.getAll());
        
        
       
        
    }
    
}
