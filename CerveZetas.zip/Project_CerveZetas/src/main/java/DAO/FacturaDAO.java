/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.Direccion;
import DTO.Factura;
import DTO.Pedido;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 *
 * @author likep
 */
public class FacturaDAO extends TablaDAO<Factura>{

    public FacturaDAO(){
        this.tabla = "CerveZetas_Factura";
    }
    @Override
    public int actualizar(Factura objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Factura f) throws SQLException {
         String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?,?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, f.getCodigo());
        prepared.setInt(2, f.getPedidoAsociado().getCodigo());
        Direccion direccion = f.getDireccion();
        if(direccion == null) prepared.setNull(3, java.sql.Types.INTEGER);
        else prepared.setInt(3, direccion.getCodigo());
        prepared.setTimestamp(4, Timestamp.valueOf(f.getFecha()));            
        return prepared.executeUpdate();
    }

    @Override
    public Factura eliminar(Factura f) throws SQLException {
        if (f == null) {
            return null;
        } else {
            return eliminar(f.getCodigo()) != null ? f : null;
        }
    }

    @Override
     public boolean existe(Factura f) throws SQLException {
        return existe(f.getCodigo());
    }

    @Override
    public ArrayList<Factura> getAll() throws SQLException {
         ArrayList<Factura> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo"); 
            Pedido pedidoAsociado = new PedidoDAO().getByCodigo(resultSet.getInt("pedidoAsociado"));
            Direccion direccion = new DireccionDAO().getByCodigo(resultSet.getInt("direccion"));
            LocalDateTime fecha = resultSet.getTimestamp("fecha").toLocalDateTime();
            lista.add(new Factura(codigo, fecha, direccion, pedidoAsociado));
        }

        return lista;
    }
    
      public ArrayList<Factura> getByCodigoUsuario(int codigoUsuario){
        try {
            ArrayList<Factura> lista = new ArrayList<>();
            String sentenciaSQL = "SELECT F.*, P.USUARIO FROM CerveZetas_Pedido P, CerveZetas_Factura F WHERE P.CODIGO = F.pedidoAsociado AND P.USUARIO=?";
            PreparedStatement prepared = getPrepared(sentenciaSQL);
            prepared.setInt(1, codigoUsuario);
            ResultSet resultSet = prepared.executeQuery();
            while (resultSet.next()) {
                int codigo = resultSet.getInt("codigo");
                Pedido pedidoAsociado = new PedidoDAO().getByCodigo(resultSet.getInt("pedidoAsociado"));
                Direccion direccion = new DireccionDAO().getByCodigo(resultSet.getInt("direccion"));
                LocalDateTime fecha = resultSet.getTimestamp("fecha").toLocalDateTime();
                lista.add(new Factura(codigo, fecha, direccion, pedidoAsociado));
            }
            
            return lista;
        } catch (SQLException ex) {
            System.out.println("Error SQL");
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    public Factura getByCodigo(int codigo) throws SQLException {
         String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            Pedido pedidoAsociado = new PedidoDAO().getByCodigo(resultSet.getInt("pedidoAsociado"));
            Direccion direccion = new DireccionDAO().getByCodigo(resultSet.getInt("direccion"));
            LocalDateTime fecha = resultSet.getTimestamp("fecha").toLocalDateTime();
            return new Factura(codigo, fecha, direccion, pedidoAsociado);
        }

        return null;
    }
    
}
