/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import java.time.LocalDateTime;


/**
 *
 * @author likep
 */
public class Factura {
    private final int codigo;
    private final LocalDateTime fecha;
    private final Direccion direccion; 
    private final Pedido pedidoAsociado;

    public Factura(int codigo, LocalDateTime fecha, Direccion direccion, Pedido pedidoAsociado) {
        this.codigo = codigo;
        this.fecha = fecha;
        this.direccion = direccion;
        this.pedidoAsociado = pedidoAsociado;
    }

    public int getCodigo() {
        return codigo;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public Direccion getDireccion() throws RuntimeException{
        return new Direccion(direccion);
    }

    public Pedido getPedidoAsociado() {
        return pedidoAsociado;
    }
    
    public double getTotalConIVA() {
        return pedidoAsociado.getTotalConIVA();
    }

    public double getTotalSinIVA() {
        return pedidoAsociado.getTotalSinIVA();
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 29 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Factura other = (Factura) obj;
        return this.codigo == other.codigo;
    }


   
    
    
    

   
    
    
    
    
}
