/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package DTO;

/**
 *
 * @author likep
 */
public enum MetodoPago {
    PayPal, Tarjeta, MonedaVirtual, nada;
    
    @Override
    public String toString(){
        switch (this) {
            case PayPal:
                return "PayPal";
            
            case Tarjeta:
                return "Tarjeta";
            
            case MonedaVirtual:
                return "Moneda Virtual";
            
        }
        return "no hay metodo de pago disponible";
    }
}
