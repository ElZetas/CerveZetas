/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;


import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 *
 * @author likep
 */
public class Producto {
    
    private final int codigo;
    private final String nombre;
    private final String descripcion;
    private final double precio;
    private final String unidadDeMedida;
    private final int iva;
    private final int stock;
    private final int stockMinimo;
    private final String foto;
    private final Usuario usuarioCrea; //references Usuario
    private final LocalDateTime fechaCreacion;
    private final Usuario usuarioModifica; //references Usuario
    private final LocalDateTime fechaModificacion;
    private final LinkedHashSet<Marca> marcas; //references Categoria

    public Producto(int codigo, String nombre, String descripcion, double precio, String unidadDeMedida, int iva, int stock, int stockMinimo, String foto, Usuario usuarioCrea, LocalDateTime fechaCreacion, Usuario usuarioModifica, LocalDateTime fechaModificacion, Set<Marca> marcas) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.unidadDeMedida = unidadDeMedida;
        this.iva = iva;
        this.stock = stock;
        this.stockMinimo = stockMinimo;
        this.foto = foto;
        this.usuarioCrea = usuarioCrea;
        this.fechaCreacion = fechaCreacion;
        this.usuarioModifica = usuarioModifica;
        this.fechaModificacion = fechaModificacion;
        this.marcas = new LinkedHashSet<>(marcas);
    }
    
    

    public int getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public double getPrecio() {
        return precio;
    }
    
    public double getPrecioConIva() {
        return precio * (1+iva/100.0);
    }

    public String getUnidadDeMedida() {
        return unidadDeMedida;
    }

    public int getIva() {
        return iva;
    }

    public int getStock() {
        return stock;
    }

    public int getStockMinimo() {
        return stockMinimo;
    }

    public String getFoto() {
        return foto;
    }

    public Usuario getUsuarioCrea() {
        return usuarioCrea;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public Usuario getUsuarioModifica() {
        return usuarioModifica;
    }

    public LocalDateTime getFechaModificacion() {
        return fechaModificacion;
    }

    public LinkedHashSet<Marca> getMarcas() {
        return new LinkedHashSet<>(marcas);
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Producto other = (Producto) obj;
        return this.codigo == other.codigo;
    }

    @Override
    public String toString() {
        return "Producto{" + "codigo=" + codigo + ", nombre=" + nombre + ", descripcion=" + descripcion + ", precio=" + precio + ", unidadDeMedida=" + unidadDeMedida + ", iva=" + iva + ", stock=" + stock + ", stockMinimo=" + stockMinimo + ", foto=" + foto + ", usuarioCrea=" + usuarioCrea + ", fechaCreacion=" + fechaCreacion + ", usuarioModifica=" + usuarioModifica + ", fechaModificacion=" + fechaModificacion + ", marcas=" + marcas + '}';
    }


    
}
