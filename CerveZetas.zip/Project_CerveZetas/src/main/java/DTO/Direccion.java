/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import java.util.Objects;

/**
 *
 * @author likep
 */
public class Direccion {
    private final int codigo;
    private final Usuario usuario; //not null
    private final String direccion;
    private final String poblacion;
    private final String provincia;
    private final int cp;

   public Direccion(int codigo, Usuario usuario, String direccion, String poblacion, String provincia, int cp) throws RuntimeException {
        this.codigo = codigo;
        if(usuario == null) throw new RuntimeException("La dirección debe tener un usuario asociado");
        this.usuario = new Usuario(usuario);
        this.direccion = direccion;
        this.poblacion = poblacion;
        this.provincia = provincia;
        this.cp = cp;
    }
   
     public Direccion(Direccion d) throws RuntimeException{
        this(d.codigo, d.usuario, d.direccion, d.poblacion, d.provincia, d.cp);
    }

    public int getCodigo() {
        return codigo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getPoblacion() {
        return poblacion;
    }

    public String getProvincia() {
        return provincia;
    }

    public int getCp() {
        return cp;
    }
   
    public boolean perteneceA(Usuario u){
        return this.usuario.equals(u);
    }

        @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + Objects.hashCode(this.usuario);
        hash = 29 * hash + Objects.hashCode(this.direccion);
        hash = 29 * hash + Objects.hashCode(this.poblacion);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Direccion other = (Direccion) obj;

        if (!Objects.equals(this.direccion, other.direccion)) {
            return false;
        }
        if (!Objects.equals(this.poblacion, other.poblacion)) {
            return false;
        }
        return Objects.equals(this.usuario, other.usuario);
    }
    
      @Override
    public String toString() {
        return "Direccion{" + "codigo=" + codigo + ", usuario=" + usuario + ", direccion=" + direccion + ", poblacion=" + poblacion + ", provincia=" + provincia + ", cp=" + cp + '}';
    }
    
    
    
}
