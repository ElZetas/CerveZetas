/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 *
 * @author likep
 */
public class Pedido {

    private final int codigo;
    private final LocalDateTime fecha;
    private final Usuario usuario;
    private final Direccion direccion; 
    private final MetodoPago metodoPago;
    private final LinkedHashMap<Producto,Integer> lineasPedido;
    private final boolean facturado;

    public Pedido(int codigo, LocalDateTime fecha, Usuario usuario, Direccion direccion, MetodoPago metodoPago, LinkedHashMap<Producto, Integer> lineasPedido, boolean facturado) {
        this.codigo = codigo;
        this.fecha = fecha;
        this.usuario = usuario;
        this.direccion = direccion;
        this.metodoPago = metodoPago;
        this.lineasPedido = lineasPedido;
        this.facturado = facturado;
    }

    public int getCodigo() {
        return codigo;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public Direccion getDireccion() throws RuntimeException {
        return direccion;
    }


    public MetodoPago getMetodoPago() {
        return metodoPago;
    }

    public LinkedHashMap<Producto, Integer> getLineasPedido() {
        return lineasPedido;
    }

    public boolean isFacturado() {
        return facturado;
    }
    
     public double getTotalConIVA(){
        double total = 0;
        for(Map.Entry<Producto, Integer> entry: lineasPedido.entrySet()){
            total += entry.getValue() * entry.getKey().getPrecioConIva();
        }
        return total;
    }
    
    public double getTotalSinIVA(){
        double total = 0;
        for(Map.Entry<Producto, Integer> entry: lineasPedido.entrySet()){
            total += entry.getValue() * entry.getKey().getPrecio();
        }
        return total;
    }



    @Override
    public int hashCode() {
        int hash = 5;
        hash = 11 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Pedido other = (Pedido) obj;
        return this.codigo == other.codigo;
    }
    
    public boolean revisarStock() {
        for(Map.Entry<Producto, Integer> linea: lineasPedido.entrySet()){
            if(linea.getKey().getStock() - linea.getValue() < linea.getKey().getStockMinimo()) return false;
        }
        return true;
    }
    
    public boolean perteneceAUsuario(Usuario u){
        return this.usuario.equals(u);
    }
    

}
